module.exports = {
    plugins: {
      tailwindcss: {
        content: ["./src/**/*.{html,js,ts,jsx,tsx}"],
      },
      autoprefixer: {},
    },
  };
  